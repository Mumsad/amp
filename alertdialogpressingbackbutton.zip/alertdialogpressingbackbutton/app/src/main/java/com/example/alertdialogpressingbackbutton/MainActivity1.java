package com.example.alertdialogpressingbackbutton;

public interface MainActivity1 {
    void onBackpressed();
}
